import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

export interface Task {
  taskId: number;
  title: string;
  description: string;
  dueDate: string;
  isCompleted: boolean;
  createdBy: number;
  createdAt: string;
}

@Injectable({
  providedIn: 'root'
})
export class TaskService {
  private apiUrl = 'http://localhost:3000/api/tasks';

  constructor(private http: HttpClient) {}

  getTasks(userId: number): Observable<Task[]> {
    return this.http.get<any[]>(`${this.apiUrl}?userId=${userId}`).pipe(
      map(data => data.map(item => ({
        taskId: item.TaskID,
        title: item.Title,
        description: item.Description,
        dueDate: item.DueDate,
        isCompleted: item.IsCompleted,
        createdBy: item.CreatedBy,
        createdAt: item.CreatedAt
      })))
    )
  }

  addTask(task: Partial<Task>, userId: number): Observable<any> {
    console.log('userId для створення:', userId);
    return this.http.post(this.apiUrl, task);
  }

  updateTaskCompletion(task: Task): Observable<any> {
    return this.http.patch(`${this.apiUrl}/${task.taskId}`, {
      isCompleted: task.isCompleted
    });
  }

  deleteTask(taskId: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${taskId}`);
  }
}
