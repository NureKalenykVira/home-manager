import { Component } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-home-page',
  standalone: true,
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.scss'],
  imports: [CommonModule, RouterModule]
})
export class HomePageComponent {
  familyName: string | null = null; // Це буде витягуватись з бекенду пізніше
  selectedTab: string = 'tasks';

  constructor(private router: Router) {}

  navigateToFamily() {
    this.router.navigate(['/family/join']);
  }

  navigateToProfile() {
    // Перехід на профіль користувача
    this.router.navigate(['/profile']);
  }

  selectTab(tab: string) {
    this.selectedTab = tab;
  }
}
