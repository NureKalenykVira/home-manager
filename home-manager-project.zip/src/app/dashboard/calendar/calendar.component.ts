import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

interface CalendarEvent {
  id: number;
  title: string;
  date: string;
}

@Component({
  selector: 'app-calendar',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './calendar.component.html',
  styleUrls: ['./calendar.component.scss']
})
export class CalendarComponent {
  events: CalendarEvent[] = [
    { id: 1, title: 'Сімейна вечеря', date: '2025-05-20' },
    { id: 2, title: 'Обслуговування автомобіля', date: '2025-05-22' },
    { id: 3, title: 'День народження мами', date: '2025-05-25' }
  ];
}
