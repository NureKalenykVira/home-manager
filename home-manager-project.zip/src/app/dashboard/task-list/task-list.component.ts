import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { TaskService, Task } from '../../services/task.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-task-list',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './task-list.component.html',
  styleUrls: ['./task-list.component.scss']
})
export class TaskListComponent implements OnInit {
  tasks: Task[] = [];
  expandedTaskId: number | null = null;
  isModalOpen = false;

  newTask: Partial<Task> = {
    title: '',
    description: '',
    dueDate: ''
  };

  constructor(private taskService: TaskService) {}

  ngOnInit() {
    const userId = Number(localStorage.getItem('userId'));
    if (!userId) {
      console.warn("Користувач не авторизований або userId не знайдено");
      return;
    }

    this.taskService.getTasks(userId).subscribe((data) => {
      this.tasks = data;
    }, error => {
      console.error("Помилка завантаження даних: ", error);
    });
  }

  toggleTaskDetails(taskId: number) {
    this.expandedTaskId = this.expandedTaskId === taskId ? null : taskId;
  }

  openModal() {
    this.isModalOpen = true;
  }

  closeModal() {
    this.isModalOpen = false;
  }

  addTask() {
    const userId = Number(localStorage.getItem('userId'));
    if (!userId) {
      alert('Користувач не авторизований');
      return;
    }
    if (!this.newTask.title || !this.newTask.dueDate || !userId) return;

    const taskToSend = {
      ...this.newTask,
      createdBy: userId
    };

    this.taskService.addTask(taskToSend, userId).subscribe(() => {
      this.ngOnInit();
      this.newTask = { title: '', description: '', dueDate: '' };
      this.closeModal();
      alert('Завдання додано успішно!');
    });
  }

  toggleCompleted(task: Task) {
    const updatedTask = { ...task, isCompleted: !task.isCompleted };
    this.taskService.updateTaskCompletion(updatedTask).subscribe(() => {
      task.isCompleted = updatedTask.isCompleted;
    });
  }

  taskToDelete: number | null = null;
  isDeleteConfirmOpen: boolean = false;

  openDeleteConfirm(taskId: number) {
    this.taskToDelete = taskId;
    this.isDeleteConfirmOpen = true;
  }

  confirmDelete() {
    if (!this.taskToDelete) return;

    this.taskService.deleteTask(this.taskToDelete).subscribe(() => {
      this.ngOnInit();
      this.closeDeleteConfirm();
    }, error => {
      alert('Не вдалося видалити завдання');
      console.error(error);
    });
  }

  closeDeleteConfirm() {
    this.taskToDelete = null;
    this.isDeleteConfirmOpen = false;
  }
}
