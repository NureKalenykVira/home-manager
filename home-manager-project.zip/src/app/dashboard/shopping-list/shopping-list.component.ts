import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface ShoppingItem {
  id: number;
  name: string;
  isBought: boolean;
}

@Component({
  selector: 'app-shopping-list',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './shopping-list.component.html',
  styleUrls: ['./shopping-list.component.scss']
})
export class ShoppingListComponent {
  shoppingItems: ShoppingItem[] = [
    { id: 1, name: 'Молоко', isBought: false },
    { id: 2, name: 'Хліб', isBought: false },
    { id: 3, name: 'Яйця', isBought: true },
    { id: 4, name: 'М’ясо', isBought: false }
  ];
}
