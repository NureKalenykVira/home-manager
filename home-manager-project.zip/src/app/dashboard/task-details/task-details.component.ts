import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-task-details',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './task-details.component.html',
  styleUrls: ['./task-details.component.scss']
})
export class TaskDetailsComponent {
  taskId: number | null = null;

  constructor(private route: ActivatedRoute) {
    this.taskId = Number(this.route.snapshot.paramMap.get('id'));
  }
}
