import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-join-family',
  standalone: true,
  templateUrl: './join-family.component.html',
  styleUrls: ['./join-family.component.scss'],
  imports: [FormsModule, RouterModule, CommonModule]
})
export class JoinFamilyComponent {
  familyCode: string = '';
  familyName: string = '';
  familyDescription: string = '';

  constructor(private router: Router) {}

  joinFamily() {
    console.log("Запит на приєднання до сім'ї з кодом:", this.familyCode);
    // Тут буде запит на бекенд для приєднання до сім'ї за посиланням або кодом
  }

  createFamily() {
    if (!this.familyName) {
      alert('Назва сім\'ї є обов\'язковою');
      return;
    }
    console.log(`Створення сім'ї: ${this.familyName} — ${this.familyDescription}`);
    // Тут буде запит на бекенд для створення нової сім'ї
    this.router.navigate(['/home']);
  }
}
