const express = require('express');
const router = express.Router();
const { poolPromise, sql } = require('../config/db');

// GET /api/tasks?userId=3
router.get('/', async (req, res) => {
  const userId = req.query.userId;

  if (!userId) {
    return res.status(400).json({ message: 'userId is required' });
  }

  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('UserId', sql.Int, parseInt(userId))
      .query('SELECT * FROM Task WHERE CreatedBy = @UserId ORDER BY CreatedAt DESC');

    res.json(result.recordset);
  } catch (error) {
    res.status(500).json({ message: 'Помилка отримання завдань', error });
  }
});

// POST /api/tasks
router.post('/', async (req, res) => {
  const { title, description, dueDate, createdBy } = req.body;

  if (!createdBy) {
    return res.status(400).json({ message: 'createdBy is required' });
  }

  try {
    const pool = await poolPromise;
    await pool.request()
      .input('Title', sql.NVarChar, title)
      .input('Description', sql.NVarChar, description)
      .input('DueDate', sql.DateTime, dueDate)
      .input('CreatedBy', sql.Int, createdBy)
      .query(`
        INSERT INTO Task (Title, Description, DueDate, CreatedBy)
        VALUES (@Title, @Description, @DueDate, @CreatedBy)
      `);

    res.status(201).json({ message: 'Завдання додано' });
  } catch (error) {
    res.status(500).json({ message: 'Помилка додавання завдання', error });
  }
});

// PATCH /api/tasks/:id
router.patch('/:id', async (req, res) => {
  const taskId = parseInt(req.params.id);
  const { isCompleted } = req.body;

  try {
    const pool = await poolPromise;
    await pool.request()
      .input('TaskID', sql.Int, taskId)
      .input('IsCompleted', sql.Bit, isCompleted)
      .query('UPDATE Task SET IsCompleted = @IsCompleted WHERE TaskID = @TaskID');

    res.status(200).json({ message: 'Статус оновлено' });
  } catch (error) {
    res.status(500).json({ message: 'Помилка оновлення статусу', error });
  }
});

// DELETE /api/tasks/:id
router.delete('/:id', async (req, res) => {
  const taskId = parseInt(req.params.id);

  try {
    const pool = await poolPromise;
    await pool.request()
      .input('TaskID', sql.Int, taskId)
      .query('DELETE FROM Task WHERE TaskID = @TaskID');

    res.status(200).json({ message: 'Завдання видалено' });
  } catch (error) {
    res.status(500).json({ message: 'Помилка при видаленні завдання', error });
  }
});

module.exports = router;
